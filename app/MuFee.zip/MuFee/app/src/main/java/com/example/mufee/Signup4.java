package com.example.mufee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

public class Signup4 extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener{

    boolean s1tf;
    boolean s2tf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup4);
        Switch s1 = (Switch) findViewById(R.id.switch1);
        Switch s2 = (Switch) findViewById(R.id.switch2);


        s1.setOnCheckedChangeListener(this);
        s2.setOnCheckedChangeListener(this);
    }


    @Override
       public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//        boolean a= isChecked;
//        //whatever you want
//        Toast.makeText(this, "State"+a, Toast.LENGTH_SHORT).show();
        switch (buttonView.getId())
        {
            case R.id.switch1:
                s1tf=isChecked;
                Toast.makeText(this, "sw1"+s1tf, Toast.LENGTH_SHORT).show();
                break;

            case R.id.switch2:
                s2tf=isChecked;
                Toast.makeText(this, "sw2"+s2tf, Toast.LENGTH_SHORT).show();
                break;
        }
    }
    public void feed(View view) {
        Intent feed=new Intent(this,feed.class);
        startActivity(feed);
    }

    public void about(View view) {
        Intent abt=new Intent(this,mufeewidget.class);
        startActivity(abt);
    }


}
