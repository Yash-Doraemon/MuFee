package com.example.mufee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Signup1 extends AppCompatActivity {
    private TextView name;
    private TextView email;
    private TextView password;
    private TextView cnfpasss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup1);
        name= (EditText) findViewById(R.id.NameEditText);
        email= (EditText) findViewById(R.id.USNeditText2);
        password=(EditText)findViewById(R.id.PasswordeditText3);
    }

    public void signup2(View view) {
        Intent su2=new Intent(this,Signup2.class);
        startActivity(su2);
    }

    public void about(View view) { Intent abt=new Intent(this,mufeewidget.class);
        startActivity(abt);
    }
}
