package com.example.mufee;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class Signup2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener, DatePickerDialog.OnDateSetListener {

   TextView tb;
    ImageButton B;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_signup2);
        B=findViewById(R.id.imageButton);

        tb=findViewById(R.id.dob);

        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment df=new DatePICKER();
                df.show(getSupportFragmentManager(),"date picker");
            }
        });

        Spinner spinner2= findViewById(R.id.spinner4);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.branch, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter3);
        spinner2.setOnItemSelectedListener(this);
        String dept=spinner2.getSelectedItem().toString();
        Spinner spinner3= findViewById(R.id.spinner5);
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.year, android.R.layout.simple_spinner_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter4);
        spinner3.setOnItemSelectedListener(this);
        String year=spinner3.getSelectedItem().toString();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text= parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void signup3(View view) {
        Intent su3=new Intent(this,Signup3.class);
        startActivity(su3);
    }

    public void about(View view) { Intent abt=new Intent(this,mufeewidget.class);
        startActivity(abt);
    }

    public void date(View view) {
        DialogFragment df=new DatePICKER();
        df.show(getSupportFragmentManager(),"Yash");
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c=Calendar.getInstance();
       c.set(Calendar.YEAR,year);
       c.set(Calendar.DAY_OF_MONTH,dayOfMonth);
       c.set(Calendar.MONTH,month);
        String str= DateFormat.getDateInstance().format(c.getTime());
        tb.setText(str);
    }
}








